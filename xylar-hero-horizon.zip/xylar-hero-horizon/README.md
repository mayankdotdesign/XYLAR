# XYLAR — Investment Intelligence Hero (Halftone Horizon)

A single-file, animated hero section for **XYLAR** (a wealth & asset management platform).
It renders a rim-lit "intelligence horizon" — two concentric glowing circle strokes with a
gradient glow (orange → cream → cyan → blue) in the gap — rendered as a **halftone dot screen**
(each dot's size tracks the underlying brightness), with a **cursor magnifier** and an idle
breathing pulse. Centered display type sits on top, with a subtle docked dashboard bar hinting
at scroll content.

Built with **Three.js** (a full-screen fragment shader) + **GSAP** (intro / pulse tweens).

---

## Files

```
index.html                      # the entire hero (markup + CSS + shader/JS)
fonts/
  Advercase Regular.woff2/.otf  # display font (headline)
  Advercase Italic.woff2/.otf   # display italic ("Engineered.")
  Advercase Bold.woff2/.otf     # logo / dashboard labels
  Geist-Variable.woff2          # body font (nav, copy, CTA)
  Geist-VariableFont_wght.ttf
```

## How to run

The file uses the **classic global Three.js build**, so it opens directly by double-click
(`file://`) — no server needed. It only needs internet to pull Three.js + GSAP from CDN.

If you prefer a server:
```
cd this-folder
python3 -m http.server 8000
# open http://localhost:8000/
```

---

## Design tokens

| Token   | Value      | Use                          |
|---------|------------|------------------------------|
| bg      | `#070708`  | page background              |
| orange  | `#d66001`  | gradient stop 1              |
| cream   | `#f1f0a8`  | gradient stop 2              |
| cyan    | `#9ffffb`  | gradient stop 3              |
| blue    | `#4757ea`  | gradient stop 4 / blue halo  |
| text    | `#ffffff`  | headline + body copy (white) |

- **Display font:** Advercase (Regular + Italic). Headline "Investment Intelligence." with
  the word "Engineered." in italic.
- **Body font:** Geist (variable).
- **CTA:** white pill "Schedule a Call"; on hover a **2px transparent gap** then an animated
  conic-gradient border (orange→cream→cyan→blue) rotating around it (+ soft outer glow).
- **Badge:** small pill "NEW · INVESTMENT INTELLIGENCE, ENGINEERED" with a gradient chip.
- **Nav:** XYLAR logo, centered links (About / Approach / Benefits / Team), "Get in touch" pill.
- **Dashboard bar:** faint docked bar at the very bottom (Portfolio / Signals / Models / …).

---

## How the visual works (shader)

All in the fragment shader inside `index.html`:

1. **`sceneColor(uv)`** builds the smooth scene:
   - A large circle centred below the fold (`c = vec2(0, -1.34)`, `R = 1.66`), x scaled by
     aspect so it stays round.
   - Two thin **circle strokes** at `R` (outer) and `R - ringW` (inner), `ringW = 0.13`.
   - A **gradient glow band** centred in the gap (`midR`), coloured by `ramp(I)`
     (black→blue→cyan→cream→orange→white by intensity).
   - `top = pow(clamp(normal.y,0,1),1.25)` so only the crest lights up; sides fade.
   - A contained **blue halo** just outside the outer ring (`bloom`, falloff `0.195`).
   - `shim` brightens the crest near the cursor x; `uPulse` breathes; `uIntro` raises/fades in.

2. **`main()`** turns the scene into a **halftone dot screen**:
   - Grid cell `= uRes.y / 95.0`; sample `sceneColor` at each cell centre.
   - Dot radius `= sqrt(luminance) * cell/2` → brighter areas = bigger dots.
   - **Cursor magnifier:** `r *= 1 + 0.95 * exp(-(dist/(uRes.y*0.18))^2)` grows dots near the pointer.

### Key knobs to tweak
- `uRes.y / 95.0` — dot density (smaller divisor = bigger/fewer dots).
- Magnifier: the `0.95` (strength) and `uRes.y * 0.18` (reach).
- Ring: `R`, `ringW`, `sw` (stroke thickness), and `c.y` (arc height).
- Blue halo spread: the `0.195` in `bloom`.
- Gradient: the `ramp()` stops.

---

## Recreate with Claude Code

Prompt to hand another Claude Code account:

> "Open `index.html` in this folder. It's a self-contained Three.js + GSAP hero for XYLAR:
> a halftone dot-screen rendering of a rim-lit gradient ring (orange→cream→cyan→blue) with a
> cursor magnifier and idle pulse, centered Advercase/Geist type, and a white CTA with an
> animated 2px-gap gradient border. Keep the fonts in `fonts/`. Preserve the shader in the
> `<script>` block — `sceneColor()` builds the ring+glow, `main()` applies the halftone.
> Modify only what I ask; verify in the browser after changes."

Fonts are licensed separately (Advercase, Geist) — include them only if you have the rights.
